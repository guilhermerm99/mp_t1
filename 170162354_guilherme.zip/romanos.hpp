#ifndef ROMANOS_HPP
#define ROMANOS_HPP

#include <string> // Adiciona a inclusão para usar std::string

int romanos_para_decimal(const std::string& num_romano);

#endif // ROMANOS_HPP
